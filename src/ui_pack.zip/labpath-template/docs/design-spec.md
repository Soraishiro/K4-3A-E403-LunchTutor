# LabPath Empty UI Template — Design Notes

Approved direction: Hybrid VLearn-inspired shell + LabPath workspace, Split Workspace, mobile Drawer, UI-only foundation. The previously populated Lab 01 mockup has been intentionally reduced to a **content-free template**. This document supersedes sample-content provisions in the earlier UI foundation spec.

- Keep only product/navigation and component/region labels needed to explain the layout.
- Do not include learner avatars, initials, account/language demo controls, lab names, stages, decisions, source names, progress values, fake AI replies, or example test results.
- Use `data-slot` placeholders for future lab header, challenge, actions, custom action, AI Coach, journey, context fields, and drawer panels. Decorative skeletons are noninteractive and not real progress.
- Maintain three-column desktop layout, workspace-first responsive layout with blank static drawer previews. No JavaScript, state, authentication, persistence, AI, or actionable dead controls.
- Styles split into `tokens.css` (palette), `components.css` (visual slots), and `workspace.css` (layout and breakpoints). Relative references only, no network dependencies.
