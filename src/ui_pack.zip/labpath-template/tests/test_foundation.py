"""UI-only contract: content-free LabPath shell with responsive slots."""
from pathlib import Path
import re
import zipfile

import pytest
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / 'index.html'
STYLES = ('tokens.css', 'components.css', 'workspace.css')


def document():
    return BeautifulSoup(HTML.read_text(encoding='utf-8'), 'html.parser')


def test_ui_shell_has_empty_content_slots_and_no_fake_account():
    doc = document()
    assert doc.html['lang'] == 'vi'
    assert len(doc.select('header.lp-topbar')) == 1
    assert len(doc.select('main#lp-main')) == 1
    assert len(doc.select('aside#lp-journey')) == 1
    assert len(doc.select('aside#lp-context')) == 1
    assert len(doc.select('section#lp-decision')) == 1
    assert len(doc.select('h1')) == 1
    assert len(doc.select('[data-slot]')) >= 8
    assert len(doc.select('.lp-slot--challenge')) == 1
    assert len(doc.select('.lp-slot--actions')) == 1
    assert len(doc.select('.lp-slot--coach')) == 1
    assert not doc.select('.lp-host-avatar, .lp-host-account, [aria-label*="tài khoản"]')
    assert not doc.select('script, form, button, textarea, input, select, a[href="#"]')
    # Section headings and slot labels are UI chrome; no content/scenario is populated.
    body = doc.get_text(' ', strip=True)
    for forbidden in ('Lab 01', 'Fork repository', 'README.md', 'LAB_GUIDE.md',
                      'pytest', '33 failed', 'Ví dụ đã chọn', 'Stage 01 of 04',
                      'AI20K · PRACTICE STUDIO', 'No live learner data'):
        assert forbidden not in body
    assert not re.search(r'\b\d+%\b', body)
    links = [s['href'] for s in doc.select('link[rel="stylesheet"]')]
    assert links == [f'./styles/{name}' for name in STYLES]
    assert all((ROOT / 'styles' / name).is_file() for name in STYLES)
    assert not any(s.startswith(('http:', 'https:', '//')) for s in links)


@pytest.mark.parametrize('width', [1440, 1024, 768, 390, 320])
def test_offline_responsive_layout(width):
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path='/usr/bin/chromium', headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': width, 'height': 900}, device_scale_factor=1)
        errors, external = [], []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.on('request', lambda r: external.append(r.url))
        content = HTML.read_text(encoding='utf-8')
        for name in STYLES:
            content = content.replace(f'<link rel="stylesheet" href="./styles/{name}">',
                                      f'<style>{(ROOT / "styles" / name).read_text(encoding="utf-8")}</style>')
        page.set_content(content, wait_until='load')
        assert page.locator('#lp-decision').is_visible()
        assert page.locator('h1').is_visible()
        assert page.locator('.lp-slot--coach').is_visible()
        assert page.locator('.lp-mobile-toolbar').is_visible() == (width < 1200)
        assert page.locator('#lp-journey').is_visible() == (width >= 1200)
        assert page.locator('#lp-context').is_visible() == (width >= 1200)
        if width < 1200:
            assert page.locator('.lp-drawer-preview').count() == 2
        metrics = page.evaluate('''() => ({
            doc: document.documentElement.scrollWidth,
            viewport: document.documentElement.clientWidth,
            color: getComputedStyle(document.querySelector('.lp-topbar')).backgroundColor
        })''')
        assert metrics['doc'] <= metrics['viewport'] + 1, (width, metrics)
        assert metrics['color'] != 'rgba(0, 0, 0, 0)'
        assert not errors, errors
        assert not external, external
        browser.close()


def test_token_and_style_boundaries():
    tokens = (ROOT / 'styles' / 'tokens.css').read_text(encoding='utf-8')
    components = (ROOT / 'styles' / 'components.css').read_text(encoding='utf-8')
    workspace = (ROOT / 'styles' / 'workspace.css').read_text(encoding='utf-8')
    for token in ('--lp-primary: #4566EF', '--lp-canvas: #F5F7FC',
                  '--lp-surface: #FFFFFF', '--lp-border: #E2E8F0'):
        assert token in tokens
    assert '@media (max-width: 1199px)' in workspace
    assert '@media (max-width: 767px)' in workspace
    assert '.lp-slot' in components
    assert '.lp-workspace' in workspace
    assert '--lp-primary:' not in components + workspace


def test_standalone_and_archive():
    standalone = ROOT.parent / 'LabPath_Empty_Template.html'
    archive = ROOT.parent / 'LabPath_Empty_Template.zip'
    assert standalone.is_file()
    html = standalone.read_text(encoding='utf-8')
    assert '<style>' in html
    assert '<link rel="stylesheet"' not in html
    assert '<script' not in html
    assert 'lp-host-avatar' not in html
    assert archive.is_file()
    with zipfile.ZipFile(archive) as zipped:
        names = set(zipped.namelist())
        for name in ('index.html', 'README.md', 'styles/tokens.css', 'styles/components.css', 'styles/workspace.css'):
            assert 'labpath-template/' + name in names
        assert not any(n.endswith(('.env', '.csv')) for n in names)
