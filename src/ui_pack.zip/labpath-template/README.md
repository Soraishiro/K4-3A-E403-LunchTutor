# LabPath — Empty UI Template

Hybrid VLearn-inspired shell with a three-region Split Workspace. This release is an **empty UI foundation**, not a demonstration lab or working simulator. The top-right account/avatar mock has been removed. The VLearn-like brand mark at top left is only a visual reference, not an official VLearn asset.

## Open

Open `index.html` directly in a browser. The separately provided `LabPath_Empty_Template.html` contains the same page with embedded styles and works as a single file. No installation, network, JavaScript, API, student data, or API keys are required.

## File responsibilities

- `index.html`: semantic shell and **empty slots only**; `data-slot` identifies future insertion points.
- `styles/tokens.css`: visual tokens.
- `styles/components.css`: blank slot and skeleton styles.
- `styles/workspace.css`: VLearn-inspired header, desktop split, mobile drawer *visual previews*.
- `tests/test_foundation.py`: empty-content, no-fake-avatar, offline and responsive assertions.

## Integration boundaries

Populate the `data-slot` regions from a later app layer; do not hardcode a specific lab into this template. At >=1200px, journey/center/context are shown together. At narrower widths, the center is prioritized and the side regions are represented by **static drawer slots**, not working interactive drawers. A future implementation must wire open/close, Escape, backdrop, focus entry and focus return. The current HTML contains no buttons, functional navigation, AI calls, progress calculation, user identity, repository operations, or sample lab guidance.
